---
dg-publish: "true"
---

* 50 kg/h y por ejemplo vamos a tener un almacenamiento de 10 días, se multiplica por 24 h y por esos 10, 15 o 30 días 
* consumo de ácido por tiempo
* un camión de ácido que hace unos 40 m^3 o 70 ton
* esas toneladas me sirven para almacenar el consumo de 1 mee, puedo almacenar 1 mes altiro

* pulpa con pH 10.5 y después al proceso CIL
* y se le agrega lechada de cal como Ca(OH)2
* tendríamos que contar también además el equipo de neutralización 
* la neutralización es aparte entonces
---
dg-publish: "true"
---

* como se puede Dimensionar? sabemos el flujo de salida del espesador y entrada a la planta cil
* como Dimensionar específicamente eso? 
* una planta CIL cuanto mineral de oro produce suponiendo la misma ley de oro de ustedes
* le vamos a pagar a alguien que procese y nos entregue el oro en costo de planta cil hasta el EW [[costo de operación]] dijo el profe
* es como maquila, cuanto te cobra alguien por procesar
* ellos les cuesta 100 y te cobran 150 para quedar con ganancia
* listo para la cianuración es la salida del CIL
* debería andar por alrededor de 500 usd/Oz de oro
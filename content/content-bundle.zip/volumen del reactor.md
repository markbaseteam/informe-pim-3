---
dg-publish: "true"
---

* multiplicar recién por el tiempo de residencia
* que debemos saberlo, en general si es autoclave de 1 a 2 horas

donde calcularlo
* 0.25 h en el tanque de acidificación para mezclar
* 1-2 horas autoclave
* estanque de almacenamiento reactivo ácido, [[flujo de ácido]]

* para el intercambiador de calor es distinto porque hay unas correlaciones que dependen solo del flujo
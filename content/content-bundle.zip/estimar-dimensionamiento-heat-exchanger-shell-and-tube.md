---
dg-publish: "true"
---

![[estimar-dimensionamiento-heat-exchanger-shell-and-tube-1700790615744.jpeg]]
Galones = 47,055.13 gal/h. 
m^3 = 178.12 m^3/h
ft^2 = 340.55 m^2
![[estimar-dimensionamiento-heat-exchanger-shell-and-tube-1700790776239.jpeg]]
- más el 35 % acá en chile por los impuestos
- X es lo que te da en el gráfico, ocupar Titanium tubes. 
- luego hay que buscar un "work index"
	- es un precio pasado con respecto al precio de hoy día, una razón. [[MyS-Cost-Index]]
- Otra forma de estimar costos es http://www.matche.com/equipcost/Default.html
- se puede ocupar la [[regla de los seis dígitos]]
- en cuanto al heat exchanger, se tiene que calcular o dimensionar en base al calor para calentar, sobre cuánta área se necesita para intercambiar, dijo el profesor en las consultas del viernes.

- no es necesario determinar la potencia en kW ni tampoco la cantidad de calor
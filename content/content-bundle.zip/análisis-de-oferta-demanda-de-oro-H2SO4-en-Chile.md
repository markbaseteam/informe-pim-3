- había un documento que habíamos visto con el david sobre el mercado del ácido sulfúrico en chile, creo que está todo como bien explicado como para revisarlo y colocar información relevante.

### Para el caso del oro:
La producción de Chile en 2022 fue del 1% de las 3100 MT globales, con alta demanda en China (29%). A pesar de la inflación en EE. UU. y la guerra Rusia-Ucrania, los precios de los "commodities" han subido. El precio del oro ha aumentado, llegando a 1936 US/oz, lo que beneficia su potencial económico. El proyecto considerará índices metalúrgicos y niveles de producción para establecer un precio de venta de oro entre 1826 US$/oz, basado en el promedio de precios de los últimos 5 años [2019-2022].

En 2021, la demanda física de oro aumentó un 10,1% a 4021 toneladas, impulsada principalmente por la fabricación de joyas (COCHILCO, 2022). Históricamente, la joyería lidera la demanda, seguida por inversiones, bancos centrales y tecnología, incluyendo electrónicos.

Las principales empresas de oro en Chile son Barrick Gold, Kinross, Goldcorp, Yamana Gold y Antofagasta PLC, que en 2022 produjeron el 1% del total mundial con 33.9 toneladas de 3637.7 toneladas (Goldhub, 2023), con la minería como principal fuente de producción.

La tabla 1 detalla la producción anual de oro y su precio promedio de 2011 a 2020. La Comisión Chilena del Cobre prevé una fuerte proyección para el oro, con una posible inversión de US$ 2,835 millones (Tassone, 2022) y un aumento del 28.6% en la producción para 2024. Esto se respalda con la puesta en marcha de los proyectos Salares Norte (Gold Fields) y La Coipa (Kinross), sumando unas 45 toneladas.

Cochilco destaca el uso del oro chileno en tecnología e industria, con un 82% de la demanda en electrónica en 2021 (COCHILCO, 2022), 14% en otras industrias y 4% en aplicaciones dentales, relevante para componentes como pantallas y sensores LED, circuitos y memorias. La minería secundaria lideró la producción de oro en 2021 con 22.9 toneladas (67%), mientras que la minería primaria aportó 11.4 toneladas (33%), sumando un total de 34.2 toneladas y un incremento del 1.46% en producción. En 2020, la producción cayó un 11.9% a 33.9 toneladas, pero el precio subió un 27.1% (SERNAGEOMIN, 2021), como se muestra en la figura 4.

En 2021, Chile produjo 34.2 toneladas de oro y en 2022, 33.9 toneladas, lo que representa una disminución del 0.87% (Goldhub, 2023). La tabla 2 muestra los diferentes productos de oro producidos en Chile, incluyendo cantidades y años de producción, relevante para seleccionar la materia prima para procesos futuros, siendo el concentrado de oro refractario uno de ellos.

- [x] ya pude copiar todo del informe anterior sobre el análisis de la oferta y demanda del oro, y puse todas sus citas!
- [x] ahora me queda por colocar el análisis del mercado del ácido sulfúrico
### Responder las preguntas
- de qué trata el mercado del ácido sulfúrico en chile? qué gráficas o qué análisis podemos rescatar?
- para qué es importante o qué usos tiene el ácido sulfúrico en chile o en el mundo, en el caso de ser exportado o importado?
- [[mercado-de-ácido-sulfúrico-en-el-mundo]]

### Presentación:
- importante: Propuestas no explicarlas solo decirlas e indicar razones porque y explicar la oxidación en medio acido. Decir las ideas principales. 
- Script: 
- Ya que es vendido como un subproducto diluido en nuestro proceso, se llevará a cabo un análisis de la situación actual del mercado del ácido sulfúrico en Chile
- Según un estudio importante realizado por COCHILCO en el año 2009, la producción de ácido sulfúrico en 2007 alcanzó un récord de 200 M de toneladas. El año siguiente tuvo una caída con una producción de 196 M de toneladas.
- [[estimaciones de producción de ácido]]

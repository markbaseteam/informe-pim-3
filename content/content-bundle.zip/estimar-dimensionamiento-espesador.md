---
dg-publish: "true"
---

- se puede usar este cálculo de ejemplo:
- [Thickener design exercise: The volume rate of flow... | Chegg.com](https://www.chegg.com/homework-help/questions-and-answers/thickener-design-exercise-volume-rate-flow-slurry-dust-catcher-37-m-min-concentration-slur-q50476622)
- [How to Size a Thickener (911metallurgist.com)](https://www.911metallurgist.com/blog/how-to-size-a-thickener)
- un cierto valor de tipo de pulpa el profe puso en el apunte del power que subió
- y a partir de ese tipo de pulpa seleccionamos el área unitaria
- luego, de esa área unitaria podemos calcular el costo del espesador
- 12 pm o después de las 5 dijo el profe que estaba disponible. 
- elegimos de 4 ft^2/ton/día que es el área unitaria del espesador
- ahora se supone que se multiplica este valor por las toneladas por día, y nos da el área en ft^2
	- este valor de TPD es el valor convertido de tph a TPD (multiplicar por 24 y luego esto multiplicarlo por el área unitaria)
- elegimos el valor intermedio de esta imagen:
![[estimar-dimensionamiento-espesador-1701989138459.jpeg]]
- ya está calculado, se eligió el valor de 3 ft^2/ton/día. 
- el [[MyS-Cost-Index]] para el espesador en capcosts estaba en 1400
![[estimar-dimensionamiento-espesador-1701999863762.jpeg]]
Volumen Espesador: 36636.8 gal/h

Tiempo de residencia: no es necesario para el calculo

Diámetro Bibliográfico: 2500 ft

- 2500 ft son 762 metros, no existe un espesador tan grande como ese

Asumiendo un comportamiento como concentrado de Cu con 3 ft/tpd , donde mi alimentación en 170.39 tph= 4089.36 tpd

Entonces para calcular nuestra área de ft^2: 4089.36 x 3= 12,268 ft^2

- Ahora con la fórmula del área de una circunferencia, se encuentra el diámetro del espesador.

A = pi x (D/2)^2 -> D = raíz(A x 4 / pi) = raíz(12,268 ft^2 x 4 / pi) = 124.98 ft = 38.09 metros (razonable).

- El precio se puede calcular directamente, no es necesario hacer ajuste por capacidad ya que estaría directamente leído en el gráfico.

- Precio = a x X^b
- a = 182.6
- b = 1.607
- Precio = 182.6 x 124.98^1.607
- Precio = 427,684 USD


- Considerando un 35 % para traerlo a Chile:

Precio final espesador : 577,374 usd.
---
dg-publish: "true"
---

* cuando conoce un equipo similar y de otra capacidad
* Cb = Ca x (SB/SA)^0.6
* estimacion del costo del equipo que necesito
* se puede extrapolar para una pequeña planta de chancho molienda o flotación, si tiene el costo de inversión de esa planta se puede calcular el costo de la otra
* Costo B x (CapA/CapB)^0.6
* lo que necesitamos es el [[volumen del reactor]]
* B es el que tiene mayor capacidad y se conoce su costo B $
* y luego la inversión de los equipos
* reactivos es el [[costo de operación]]

* valor por las razones de las capacidades de los equipos
* definir que capacidad tiene que tener el equipo
* costo de inversión son los principales equipos del proyecto
* preguntar al profe para los costos de equipos
* si el costo es de otro año, actualizar el precio y si es tema de la capacidad se debe hacer igual
* como podríamos entonces determinar el costo de una planta CIL o estimar su coste? Podría ser por una planta de SX?
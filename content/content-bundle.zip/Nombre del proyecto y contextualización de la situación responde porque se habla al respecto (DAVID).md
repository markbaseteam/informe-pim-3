- 1. Introducción: 
    

Nuestro proyecto basado en la viabilidad técnica y económica de la producción del metal a partir de concentrado pirítico, es un proyecto que se tiene que hablar al respecto ¿ por qué se preguntarán ustedes , debido aquí estos concentrados poseen una mayor ley además de que Chile es el 4to país con las mayores reservas mundiales del 8% y por último dado que en el mercado sabemos que hay un aumento del precio del  oro sostenido en los últimos 10 años , dónde a partir de lo anterior se genera una interrogante ¿Cómo se puede lograr que esto se lleve a cabo?  y será rentable? , esto lo veremos a continuación: 

Mercado: 

Precio: 

En la siguiente imagen se puede ver una proyección del precio del oro en alza entre estos últimos 10 años lo cual es han sido impulsados por el contexto mundial de la gran demanda que existe por ejemplo en China con el 29% y las guerras actuales como la de Estados Unidos con Rusia. 

Demanda: 

De igual manera se puede observar que la demanda histórica con un aumento donde la demanda principal ha sido en joyas, inversiones y finalmente la tecnología  

Oferta: 

En la imagen de la oferta en se puede observar que la principal oferta es por medio de la producción minera y por otro lado por reciclaje,  siendo los niveles de oferta similares a través de los años cercano a las 5000 ton anuales. 

Productos: 

En función los productos en Chile se pueden observar en la siguiente tabla del SERNAGEOMIN  que el principal producto es el metal doré  seguido del concentrado de oro.   

- guerra de estados unidos con rusia??? no están en guerra esos países..
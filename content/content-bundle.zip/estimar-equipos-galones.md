- Equipos Para Dimensionar

1)      Tanque de acidificacion

2)      Intercambiador de calor

3)      TPOX

4)      Despresurizador

5)      Acondicionador de pulpa ( % de solidos)

6)      Circuito CIL

- convertir de t/h a gal/h?

### Búsqueda de catálogos:
busca catálogos de equipos para tratar de dimensionar en galones americanos gal/h, o en m^3/h, o L/h, de cualquier 
Equipos Para Dimensionar
1)	Tanque de acidificación
2)	Intercambiador de calor
3)	TPOX
4)	Despresurizador
5)	Acondicionador de pulpa ( % de solidos)
6)	Circuito CIL



- costo del equipo y capacidad volumétrica 
- [[consultas-proyecto-PIM]], en base a [[regla de los seis dígitos]]
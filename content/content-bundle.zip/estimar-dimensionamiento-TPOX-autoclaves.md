---
dg-publish: "true"
---

- Todo lo que entra al autoclave TPOX en volumen en gal/h es [[consultas-proyecto-PIM]]
- buscar otro gráfico en internet porque en capcosts no aparece creo
- duda en [[consultas-proyecto-PIM]] que no sabemos si es que como son 4 aspas de autoclave en TPOX, SI SON, y es un autoclave horizontal. 

- quedamos cortos con este:
![[estimar-dimensionamiento-TPOX-autoclaves-1700877021254.jpeg]]
- 350 kPa son 50.75 psi
- Ahora, considerando la alimentación a la autoclave TPOX, se tiene también la correlación entre la capacidad en galones, considerando el tiempo de residencia de 2 horas
![[estimar-dimensionamiento-TPOX-autoclaves-1702002275617.jpeg]]
- Capacidad máxima bibliográfica: 1000 gal  
- Precio capacidad bibliográfica: 400000 USD

- Tiempo de residencia: 2h

- Capacidad actual: 42625.81 gal/h x 2 h= 85251.62 gal

- Realizando un ajuste de precios por capacidad
- Cb = 400,000 x (85,251.62/1000)^0.6
- Cb = 5,760,783 USD
- ahora implementando el [[MyS-Cost-Index]] quedaría como:
- Implementando M&S, 5,760,783 USD x 1703.14/1400 = 7,008,157 USD

- Considerando un 35 % de importación a Chile:

- Costo total: 7,008,157 USD + 7,008,157 USD x 0.35 = 9,461,012 USD
##### Determinación de la potencia
- me imagino que va por determinar el precio para llevar la operativa a 350 kPa y a una temperatura de 230 °C

###### Densidad de mineral en la corriente de alimentación al Autoclave TPOX
**Cálculo de la densidad del material con una proporción de 9.43% de pirita**

Con los mismos supuestos anteriores, pero con una proporción de pirita de 9.43% y el resto de sílice, el cálculo de la densidad del material es el siguiente:

```
ρ = (2,65 * 0,9057 + 4,95 * 0,0943) / (0,9057 + 0,0943)
```

```
ρ = 2.87 kg/m3
```
- esta sería una imagen aproximada de lo que sería un autoclave:
![[estimar-dimensionamiento-TPOX-autoclaves-1702159266088.jpeg]]
### AUTOCLAVE

The autoclave is the primary equipment in pressure processes and is the largest single pressurized equipment in the pressure circuit; it is a pressure reactor. This is the part of the process where chemical reactions like leaching and precipitation happen.

The autoclave vessel is divided into compartments consisting of an agitator unit and baffles divided by walls. The agitator mixes the slurry throughout the process. Different types of agitators are available to fulfill the different process requirements of various applications. To improve the efficiency of the agitators there are baffles in every compartment. These improve the mixing efficiency by directing horizontal flow to vertical movements, which prevents vortex formation and enhances axial flow. This leads to reduced mixing time by improving the suspension of solids and dispersion of gas.

- el llamado "flash vessel" puede ser considerado como el "Flash Tank" [[estimar-dimensionamiento-flash-tank]]
- [[determinar-potencia-de-Autoclave-TPOX]]
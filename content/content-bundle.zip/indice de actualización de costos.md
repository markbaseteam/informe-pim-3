---
dg-publish: "true"
---

- es el IPC
- había una fórmula en el PPT para calcularlo
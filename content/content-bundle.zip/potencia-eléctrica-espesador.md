- considerando lo dicho anteriormente:
- y buscar en mirrorthink
- lo que me dijo mirrorthink:
- 1. **Determine the Drive Torque**: The torque required to rotate the rakes within the thickener is a critical factor in determining the power consumption. This torque depends on the yield stress of the material being thickened and the rake design. The torque can be estimated based on the thickener manufacturer’s data or from empirical correlations based on the yield stress of the material.
    
2. **Calculate the Rake Speed**: The rake speed is the rotational speed of the rakes, typically measured in revolutions per minute (RPM). This speed is set to ensure proper solids transport without causing undue turbulence that could hinder settling.
    
3. **Power Calculation**: Once the torque (T, in Newton-meters) and the rake speed (N, in RPM) are known, the power (P, in watts) can be calculated using the formula:  
    [ P = \frac{T \times N \times 2\pi}{60} ]  
    To convert the power from watts to kilowatts, divide by 1000:  
    [ P_{kW} = \frac{P}{1000} ]
    
4. **Underflow Pumping Rate**: The power required to pump the underflow can also contribute to the total power consumption of the thickener. This can be calculated by considering the flow rate, the density of the underflow, and the pumping head required.
    
5. **Total Power Consumption**: The total power consumption of the thickener is the sum of the power required to rotate the rakes and the power required to pump the underflow.
    

Here is an example calculation with hypothetical values:

- Assume the drive torque required for the 38-meter diameter thickener is 30,000 Nm (this value would typically be provided by the thickener manufacturer or determined through testing).
- Assume the rake speed is set to 1 RPM for gentle movement of the settled solids.
- podría buscar entonces en algún catálogo para determinar la potencia de una según el diámetro, estimar para un espesador de 38 metros, o bien calcularlo en base a supuestos encontrados en internet. 
- [Thickener-Design-2.pdf (911metallurgist.com)](https://www.911metallurgist.com/blog/wp-content/uploads/2016/03/Thickener-Design-2.pdf)
###### Potencia de un espesador
- para poder calcular la potencia, hacemos una serie de supuestos
- lo primero es encontrar el torque del equipo, que se encuentra con la fórmula:
- T = Torque = K x D^2 (unidades en ft x lbs)
- en donde D es el diámetro del espesador en pies, del [[estimar-dimensionamiento-espesador]] el diámetro era de 38 metros, eso a pies es = 124.7 ft
- se escoge un valor de K para la dureza del mineral, como es un concentrado de hierro, podemos estimar que es de una dureza mediana:
- escogemos un factor de K = 15 
![[potencia-eléctrica-espesador-1702086766314.jpeg]]
- entonces el torque:
- 20 x (124.7 ft)^2
- 311,001 ft x lb (x 1.35)
- 419,852.43 N x m
- ahora, ocupando un "rake speed" de un valor de 8 a 12 m/min (velocidad de las rastras), elegimos el valor de 10 m/min
- transformando a rpm:
- 10 m/min /(pi x 38) = 0.083 rpm
- elegir 0.12 rpm por ejemplo
- ahora calculando la potencia para el motor eléctrico que mueve las rastras:
- P = 2 x pi x N x T / (60 x Eff x 1000) 
- P = 2 x pi x 0.083 rpm x 419,852.43  N x m / 60 x 0.5 (eficiencia) x 1000.
- P = 7.29 kW
###### cálculo página de internet
- es bastante parecido a lo que da en esta página:
[Thickener (metengineer.com)](https://metengineer.com/thickener.html)
![[potencia-eléctrica-espesador-1702089800622.jpeg]]
---
dg-publish: "true"
---

- para todos los equipos que tenemos
- [[estimar-dimensionamiento-espesador]]
- [[estimar-dimensionamiento-agitator-tank]]
- [[estimar-dimensionamiento-heat-exchanger-shell-and-tube]]
- [[estimar-dimensionamiento-TPOX-autoclaves]]
- [[estimar-dimensionamiento-flash-tank]]
- [[estimar-equipos-galones]]

- Una vez hecho esto, [[costo de operación]]

- Links para revisar más adelante:
- https://metengineer.com/thickener.html
- https://www.pdhonline.com/courses/m371/m371content.pdf
- https://www.sciencedirect.com/science/article/abs/pii/S0304386X05002793
- https://www.911metallurgist.com/blog/calculate-capacity-agitator-conditioner
- https://myengineeringtools.com/Piping/Power_Agitator_Calculation.html
- https://www.aiche.org/sites/default/files/community/262801/aiche-community-site-event/514546/aicheshellandtubeheatexchangersdrm11-15-19.pdf
- https://www.911metallurgist.com/blog/leaching-plant-design
- https://youtube.com/watch?v=2ASqplhOyEk

### Links para evaluación económica
- [[Links-evaluación-económica-PIM]]


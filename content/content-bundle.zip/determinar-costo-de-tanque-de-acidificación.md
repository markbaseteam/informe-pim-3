- se dimensiona en base a los galones según capcosts
![[determinar-costo-de-tanque-de-acidificación-1702000429596.jpeg]]
- galones totales por el tiempo de residencia, OK
- Volumen de tanque: 41731.7 gal/h

- Tiempo de residencia: 0.25 h

- Volumen de tanque: 10432.925 gal

- Volumen de tanque bibliográfico:1500 gal

- Costo de tanque bibliográfico:4000 USD
	- eligió un acero 304 en vez de un 316L

- Realizando un ajuste de precios por capacidad: [[regla de los seis dígitos]]
- Cb= Ca x (Sb/Sa)^0.6
- se capacidad de B y se capacidad de A, dado un costo de A puedo saber el costo de B.
- 12,807 USD 
- lo que quedaría por corregirle el [[MyS-Cost-Index]] al año 2023, y ver para qué cost index calculó este precio. Fue para 1400
- por la corrección, el valor actual al 2023 sería de:
- 12,807 USD x 1703.14/1400 = 15,580 USD.
- Más el costo del 35 % de importación en Chile:
- 21,033 usd.
![[determinar-costo-de-tanque-de-acidificación-1702000587728.jpeg]]
- pero no considera la agitación ni nada de eso, ni las aspas como en el cálculo que hice para [[determinar-potencia-de-un-agitador-porc-sólidos]]
- este es igual que el [[determinar-precio-del-neutralizador]]

### CONSULTAS 07_09
- Comprender y analizar contexto actual ante la problemática.

- Realizar un Estudio Mercado dentro de un enfoque técnico sobre la oferta y la demanda, con la proyección del precio del oro.

- Determinar la factibilidad económica de la producción de oro metálico a partir de concentrados piríticos. (???? tengo dudas con esta parte.) SÍ está correcto
### Consultas 28 Sept
- El flowsheet debe de ser usado para realizar los balances, los balances respectivos que se piden son el balance de calor y de materia 1) encontrar el flowsheet 2) las reacciones del proceso
- más que nada en el tema del impacto ambiental, se debe colocar qué hacer con los residuos, porque todo proceso metalúrgico tiene un descarte o rechazo, si los residuos de lixiviación tienen cianuro (creo que vi en uno de los flowsheet una piscina o estanque que son las colas del proceso de CIL)
	- si es que hay un riesgo estructural por derrumbe
	- o si va a un tranque de relaves
	- los efluentes líquidos y gaseosos son los que tienen más problemas
	- Justificar solamente una alternativa en la introducción
[[informe-final-pim]]

### Consultas informe final:
- Qué pasaba con el dimensionamiento de un equipo, qué unidad tiene que estar, en galones/hora o en gal/día? para poder estimar el dimensionamiento de un equipo. 
	- en m^3/h
	- pero se supone que tienes que quitarle la unidad de tiempo según corresponda, tipo el tiempo de residencia en el reactor
- Una bomba hidráulica podría tener una relación con un tanque de agitación? en el caso de [[estimar-dimensionamiento-agitator-tank]]
- hablando de la potencia para el [[estimar-dimensionamiento-TPOX-autoclaves]] se puede considerar un cálculo mediante la presión necesaria para hacer funcionar el equipo y las 4 autoclaves "sumadas en serie"??
#### Consultas 12_12: teams
- es mucho mejor hacer las consultas online porque le podemos mostrar el excel que estamos haciendo
- todo el calor lo aportamos con resistencia eléctrica para el TPOX (y sale más caro) es una posibilidad dijo el profe, que los kW del TPOX son razonables
	- indicar que el calor considera el necesario para el proceso
- agitadores es si o sí con eléctrica
- despresurizador no requiere ni energía eléctrica ni alimentar con calor
- intercambiador no necesita energía eléctrica (usa la del flash y no requiere combustible)
- espesador debería ser mayor su kW que la potencia del estanque de % de sólidos y el de acidificación [[potencia-eléctrica-espesador]] debería tener un torque mayor dijo el profe, entonces debería buscar eso y corregir ese valor
- el costo de operación es el OPEX
- las tablas: no van con decimales en la plata $
- el CAPEX ya considera el costo de las bombas, no es necesario colocar el nro de bombas específico y la potencia de cada una.
- respecto de la iluminación: asumir 5% más para la iluminación, del consumo total de energía eléctrica
- poner el precio por tonelada de ácido (en vez del 743 $) colocar un valor razonable como de 150 usd máximo, ya que las fundiciones lo venden a 100 usd la tonelada
- no generamos ácido sulfúrico puro, si no que una solución diluida con ácido sulfúrico, suponer un valor de 40 % de pureza, entonces estaríamos ganando el 40 % de esa venta pura (de toda esa ganancia)
	- en cuanto al costo de transporte, ya no existe, ellos tienen que pagar para venir a buscar el ácido y listo
	- o sea que el costo de transporte lo ve el comprador
- el análisis se hace a un horizonte de 10 años máx, considerando nuestras bajas ganancias, se podría tener ese horizonte
- la [[depreciación de los equipos-PIM]] igual se puede considerar dijo el profesor
- el costo de operación es de todos los años! y podemos considerar este costo como (costo fijo y variable) es como el costo total nomás que se paga todos los años para operar.
- duda con la ganancia del oro: ojo que NO vendemos oro! ya que esto sería considerar además el costo de tratamiento de la planta CIL, de la planta cianuración, hasta la producción de oro en barras o lingotes de 1 kg..
- entonces, nosotros ganamos únicamente con el tratamiento o cobro de tratar ese concentrado pirítico
- suponer como máximo un 15-20 % de lo que se gana vendiendo el oro (11 M de ganancia en USD x 0.20) y da como un valor de 2 M y algo
	- esa es nuestra ganancia, cobrar por el costo de tratamiento del concentrado pirítico refractario.
	- era como 2,262,196 usd
	- es el ingreso por operación maquila
- en cuanto a la tasa de descuento, suponer un valor de 8-10 %
- 2.26 ton/usd en la maquila, "no colocar ganancia de producción"
- en cuanto al [[estimar-dimensionamiento-TPOX-autoclaves]] se bajó el tiempo de residencia a 1 hora (ver archivo informe final meta)
	- para que tengamos un menor precio en el TPOX
- en cuanto al análisis de sensibilidad, podemos hacer la evaluación y cuando de VAN<0 
	- tenemos que determinar el precio de la maquila tal que la VAN=0 y 
	- y ver el resultado, por ejemplo cobrar 5 usd/ton para que el proyecto sea atractivo
- análisis de sensibilidad solamente hacer un gráfico de VAN (eje Y) v/s precio de la maquila (eje X)
- no es necesario tener TIR graficada en ese caso
- Payback: si sale el VAN<0 puede ser que este parámetro esté muy alto, pero en el caso de tener un payback < 10 años sería interesante colocarlo igual. 

#### Consultas finales
- las últimas consultas al profesor parada
- venta de ácido nada más -> no es commodity ya que no es 100 % puro
- impuesto a las utilidades es del 27 %
- costo maquila nada que ver con gasto de administración y venta
- se puede poner separado (gasto de administración y venta)
	- tipo el 5 %, aunque no debe ser muy significativo o hasta el 10 % aproximado del costo de operación, el gasto de administración y venta, pero más que el puro número, qué es en sí? xd
- ley de oro creo que de 20 g/t, que son 20 x 10^-6 g de oro, que entra al proceso, y se producen los 170 y algo kg de oro anualmente
- cuánto vale el oro en 1 t de mineral, cobrar menos del 10 % de eso (contenido)
- potencial valor de 100 usd/ton máximo (no hay problema)
	- cobrar maquila como tope 100 usd
- el informe resumido que sería? anexos
- equipo poner listado y capacidades, descripción de equipos y eval. técnica (dimensionamiento), costos se pone en la parte de evaluación económica
- costo de kW 0.25 usd/kWh está bien aunque es un poco caro, 0.20 usd/kWh puede ser
- en cuanto al costo del agua, puede ser de 1.5 usd/m^3 para las minas, el valor de 0.2 usd/m^3 está muy bajo!
- en cuánto a los supervisores, 4 (3 turnos + 1 descansa)
- metalurgistas con 1 basta para monitorear todo el proceso, tipo 1 turno de día
	- y los operadores como los administradores están bien
	- presentar hasta el viernes de la próxima semana -> debes entregar hasta el día lunes como máximo
- Jueves la presentación puede ser por teams dijo el profe!!
#### Avanzar en el informe: colocar los resultados
- [x] Colocar un resumen ejecutivo
	- [x] yo creo que podría colocar la misma parte de la descripción del problema y decirle a mirrorthink tipo "haz un resumen ejecutivo de esto y que suene profesional".
- [x] Colocar la introducción.
	- [x] este ítem corresponde a la justificación del primer informe, entonces, esto se MANTIENE!
	- podría dejarlo así tal cual entonces, o bien desarrollar más la idea. 
- [x] Colocar los objetivos. [[objetivos-informe-3-pim]]
- [x] Colocar la parte del análisis de la oferta y demanda del oro.
	- [ ] colocar e investigar la misma parte de la oferta y demanda pero para el ácido sulfúrico [[análisis-de-oferta-demanda-de-oro-H2SO4-en-Chile]]. la del oro es [[Gráficos-producción-de-oro-chile]]
	- [ ] en cuanto al ácido, buscar esa información y hacerla lo bastante resumida
	- [ ] colocar igualmente la cosa esta del
- [ ] Colocar la parte de la evaluación técnica
- [ ] Colocar la parte de la evaluación económica
- [ ] En cuanto a la bibliografía
	- [x] Colocar la misma bibliografía que para el informe 2
	- [x] Agregar la misma bibliografía que para el informe 1 en la parte del análisis de la demanda y oferta, pero más resumido!
	- [ ] Agregar la bibliografía para el análisis de oferta y demanda del ácido en chile. 
- el formato está en [[informe-final-pim]]
- alguna parte del formato de este informe final de pim estaba un ítem que podríamos usar al principio, en esta misma nota sale.
- revisar por última vez a la corrección del primer informe por parte del profe.

- harto ánimo
- terminar de una vez por todas con esto
- ayudarse de la IA y de Ditto para ir copiando-pegando datos de los informes anteriores o tablas a este documento. 

### Para la presentación:
- son partes de texto que he ido eliminando dado que el informe queda extremadamente largo, así que las colocaré por acá por si la usamos para la presentación:
- [[justificación-de-alternativa-pim-presentación]]
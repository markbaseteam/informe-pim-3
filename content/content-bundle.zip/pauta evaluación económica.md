---
dg-publish: "true"
---

* estimación del orden de magnitud +-50 %
* estudió de estimación 30 %
* estimación preliminar (cotización) 20 %
* estimación definitiva 10 %
* estimación detallada 50 %
* [[regla de los seis dígitos]]
* [[indice de actualización de costos]]
* [[marshall seift cost index]]
* [[libro de capcosts]]
* [[página web equipcost]]
* hay un factor de 30 a 100% de instalación del equipo
* p ejemplo 1.3 y 2.0 el costo
* luego este factor de equipos instalados se utiliza en los demás ítem
* instrumentación, valor promedio intermedio como referencia
* hay un ítem que es sobre los edificios y trabajos en terreno
* planta aire libre o bajo techo o 100 techo 
* tomar el valor intermedio de ing y construcción 
* y ya con eso tendríamos el costo de la inversión 
* equipos dimensionados en base al balance de masa
* [[costo de operación]]
* [[costo de energía]]
* como para el 15 de diciembre se puede hacer la entrega y la presentación dps
* y dps se hace más difícil si es que se atrasan en este informe!! jsjs
---
dg-publish: "true"
---

* energía es kW/h
* potencia es kW
* van a suponer que 75 % de potencia instalada se va a consumir por 24 horas al día 
* luego determinar los kWh al año que se va a requerir
* equipos anexos por ejemplos las bombas
* determinar en base a un criterio
* y representa un porcentaje de la potencia total de la instalación 

- este es el link para revisar la presentación PPT que creó el navarrete!
- https://udeconce-my.sharepoint.com/:p:/g/personal/dnavarretey2019_udec_cl/EUFQJUbLAE1GiNaUMehmMWoBuZytBZIKys8i5WU5NLsDvA?e=O0JI0q

#### Documento final con los diálogos
[TAPIZAO EN ORO.docx (sharepoint.com)](https://udeconce-my.sharepoint.com/:w:/g/personal/dnavarretey2019_udec_cl/EdQYBrXBD7tCoH9aWnBlvkUBLGFlgh5WbPWDJ8O9CykgAQ?e=4%3AxR8FYn&fromShare=true&at=9)

### Diálogos de PIM
Presentación 

1. [[Nombre del proyecto y contextualización de la situación responde porque se habla al respecto (DAVID)]], [[análisis-de-oferta-demanda-de-oro-H2SO4-en-Chile]] (SEBA) 
    

2. Indicar opciones generalizadas que se consideraron y porque se eligió dando razones justificadas. (enumeración) (SEBA) [[análisis-de-alternativas-y-elección]]
   - yo creo que podría nombrar entonces el flowsheet de las 3 alternativas, y describir las ventajas y las desventajas del proceso, en términos de recuperación, situación del mercado, confiabilidad tecnológica, etc. 

3. Explicar proceso y descripción de Flowsheet  (DAVID) 
    

4. Indicar el dimensionamiento de equipos (DAVID) 
    

5. [[Análisis económico realizado]] (SEBA) 
    

6. [[Análisis de sensibilidad]] (SEBA), indicar conclusión de VAN, TIR, IVAN, PayBack, (DAVID)


- Descripción del Proceso: En nuestro proceso de oxidación a alta presión en medio ácido  se puede observar en el siguiente FlowSheet , en el que se trata de un concentrado pirítico  hoy en el cual su composición es: 
    

- El cual va a un estanque de acidificación para controlar y obtener un PH menor que dos  
    

- Posteriomente  se calienta la pulpa a un intercambiador de calor. 
    

- Luego ingresa a un autoclave TPOX en el cual se adiciona oxígeno, para lograr la oxidación a alta presión en medio acido. 
    

- Logrado esto va hoy va hacia un tanque flash que tiene como por objetivo la despresurización de la pulpa y evaporar el agua donde el calor sensible del agua evaporada con una eficiencia del 59.49% es suministrada al intercambiador de calor  
    

- Luego esto nuestra corriente del tanque flash se dirige hacia un tanque de ajuste de sólidos acompañado de un flujo externo de agua para poder así lograr un 30% de sólido en la composición de la pulpa. 
    

- Una vez alcanzado esto pasa por nuestro espectador que finalmente va a nuestra planta CIL que anteriormente pasa por un Tanque de Neutralización. 
    

- También se puede ver que el flujo saliente del espesador va hacia a un nodo en el cual vamos a asignar un 70% de esta solución al mercado hay un 30% en la red circulación hacia nuestro tanque de acidificación para que nuestro proceso sea cíclico y obviamente el ácido sulfúrico que nosotros vendamos sea ácido diluido 
    

Posteriormente una vez definido nuestro Flowsheet y nuestro balance de calor y materia se pudo con ello lograr el dimensionamiento y costo de nuestros equipo y la planta de operación, lo cual se puede mostrar a continuación. 

El libro que se ocupo para realizar este proceso fue CAPCOST en el cual se ocuparon la regla de los 6 digitos que es :……. Y el índice de precios que es:………
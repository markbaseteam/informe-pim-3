---
dg-publish: "true"
---

* por ejemplo para el ácido sulfúrico 
* cal, agua petróleo, esos insumos deben de estar en el balance de masa 
	* cal usamos en el [[determinar-precio-del-neutralizador]] y en el oxígeno del [[estimar-dimensionamiento-TPOX-autoclaves]]
	* [[determinar-precio-insumos-O2-Cal-H2O]]
	* y el agua que debemos agregar al [[determinar-potencia-de-un-agitador-porc-sólidos]]
	* [[determinar-potencia-de-un-intercambiador-calor-tubo-carcasa]]
	* [[determinar-potencia-flash-tank]]
* petróleo reflejado en el balance de calor
	* el costo de la energía eléctrica, que viene dada de la potencia, la podemos calcular mediante el balance de calor? para el TPOX, y para
	* [[potencia-eléctrica-espesador]]
* luego energía eléctrica de la capacidad o potencia de los equipos q estamos usando
* mano de obra, importante definir si es una planta nueva o ya existente [[determinar-costos-de-mano-de-obra]]
* para el gerente personal y personal administrativo
* colocar operadores, mantención
* si es continua o trabajan en turnos
* 4 turnos
* 3 turnos al día
* 10 operadores, 40 turnos más uno que esta descansando
ítem de mantención solo basado en el costo de los equipos
* cuanto me cobra para tratar la solución en la planta SX EW
* o bien por la planta CIL EW
- luego sacar el coste de la planta CIL (transporte + tratamiento)
- producimos tanto ácido
	- y costo de transporte
### consultas
- cuánto petróleo se necesita en el autoclave
- necesitamos un [[coef global de transferencia de calor unidades]] en el balance de calor
	- cuánto kcal de calor debo sacarle
	- depende del tipo de intercambiador de calor 
	- si lo vamos a calentar con líquido-líquido o vapor-líquido
	- solamente hacerlo por flujo. 
- este debe de ser el OPEX? SI
- [[consultas-proyecto-PIM]]
[Simple Calculation Methods to Estimate Power Required to Rotate Agitator Impeller (missrifka.com)](https://missrifka.com/equipments/simple-calculation-methods-to-estimate-power-required-to-rotate-agitator-impeller.html)
- primero se puede elegir un valor de un "power number" que es el Np, en función de la geometría, se utilizará para el cálculo este número junto con una velocidad de agitación escogida y con la geometría del agitador.
![[determinar-potencia-de-un-agitador-1701989857402.jpeg]]
###### Consideraciones
- se eligió una razón de W/D para las aspas del agitador, de 1/5
	- entonces el valor del Np es de 1.70
- se consideró una turbina de 6 cuchillas, "six blade impeller", la cual tiene el valor de 1.70 en power number
- se consideró que las aspas o cuchillas son de 12 pulgadas de ancho y un valor de 58 pulgadas para el diámetro. 
- se consideró un equipo de acero inoxidable 316 L puesto que trataría pulpa ácida
- por ende, el valor de Np escogido es:
	- Np: 1.70
- W = 12 in y D = 58 in
- rho: gravedad específica del líquido
- calculando ahora la potencia
- P  = 1.70x 1.00 x 85^3 (rpm) x 58^5 (in) /(1.524 x 10^13) = 45 hp
- considerando ahora una eficiencia de 85 % para el motor
- 45/0.85 = 53 hp
- Ahora seleccionamos en la página de costos al equipo:
![[determinar-potencia-de-un-agitador-1701993933207.jpeg]]
- se tiene que actualizar ahora mediante el [[MyS-Cost-Index]], este precio se actualiza multiplicando 28,600 usd x 1703.14/1494.52 = 32,592 usd -> costo final en USA
- ahora, el costo de importación a chile, considerando un 35 % -> 44,000 usd. redondeando (cálculo 43,999.2 usd)

###### Referencia de cálculo
**Reference**

Chopey, Nicholas P, “Handbook of Chemical Engineering Calculations – Fourth Edition”, The McGraw-Hill Companis, 2012.

- Este cálculo corresponde entonces para el equipo de estanque de ajuste de % de sólidos. 
###### Ahora calculando la energía eléctrica para ambos
- teniendo en cuenta que calculé y me dio un total de 53 hp, considerando que los dos estanques, tanto el [[determinar-costo-de-tanque-de-acidificación]] como para el porc. de sólidos (esta nota)
	- se calcula 39.52 kW de potencia para cada equipo, con la conversión de hp a kW
	- ahora, aproximando a un equipo comercial de 40 kW de potencia, y teniendo dos estanques agitados (uno de % de sólidos y otro de acidificación), tendríamos 40 kW x 2 = 80 kW de potencia total, y con esto podemos determinar la energía eléctrica. 
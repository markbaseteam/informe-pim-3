* calcular el precio del más grande que nos da en el libro y lo actualizamos con el Marshall and index del valor de hoy que es como de 2000 [[pauta evaluación económica]]

para el flash
* si el tiempo de residencia del vapor es para 1 minuto para un tiempo razonable, solamente para la fase gas, suponer que se todo va en fase gaseosa como gas ideal
* es un poco más chico pero más menos razonable con el autoclave

para el %solido
* tr de 0.20 hora

espesadores
* necesitamos valores de área unitaria
* buscar la pulpa que se parezca más a la de nosotros
* toneladas por día de sólido
* y calcular según el diámetro del espesador
* considerar un concentrado de cobre el mismo comportamiento 4 valor (video grabado)
* el solido hay que convertirlo a TPD por ejemplo 1000
* vendría a ser el mismo sólido que entra y que sale
* y el área 4 x 1000 ft^2
* y se ve en el gráfico del libro
* unidades en galones o m^3?? para el informe podemos usar en Litros o [m^3]


tiempo de residencia del intercambiador de cslor
* que pide el gráfico
* no hay tiempo de residencia en el intercambiador
* ni en el espesador entonces
* ambos se Dimensionan por área que es lo principal
* 5000 ft^2 valor arbitrario por ejemplo, o buscar en la simulación de Syscad!!! puede que aparezca
* y mi calor es 50,000 kcal por hora
* entonces coeficiente de transferencia de calor es 50,000 kcal/5000 ft^2 [[coef global de transferencia de calor unidades]]
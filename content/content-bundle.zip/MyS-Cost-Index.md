---
dg-publish: "true"
---

- se llama Marshall and Swift cost index (M&S)
	- tiene la utilidad de actualizar los precios de cualquier equipo a un año actual.
	- se utiliza entonces en [[regla de los seis dígitos]]
- tiene varios valores de indicadores
- está calculado en base información de 47 países
- hay una específica para minería y molienda 
- Corresponde a un [[índice-de-actualización-de-costos]]
- entonces para el cálculo [[estimar-dimensionamiento-heat-exchanger-shell-and-tube]] tenemos 
- En base a este gráfico se puede encontrar el valor del Índice de M&S debido a la última correlación o línea de tendencia:
![[MyS-Cost-Index-1700792492656.jpeg]]
- haciendo el cálculo para el 2023: -4.519 x 10^4 + 23.18 x (2023) = 1703.14
- haciendo el cálculo para el 2014: -4.519 x 10^4 + 23.18 x (2014) = 1494.52 [[determinar-potencia-de-un-agitador-porc-sólidos]]
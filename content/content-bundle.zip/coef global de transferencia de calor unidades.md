---
dg-publish: "true"
---

* coeficiente de transferencia de calor en página llamada scielo.sld 
* otra pregunta es sobre la [[planta CIL]]
* se usa más el watt/mK
* kcal hora se transforma a watts 
* kcal/hmK

* potencia de todos los equipos es costo energía eléctrica planta en [[costo de operación]]
* la energía no va en el [[capex]]
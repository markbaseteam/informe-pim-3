- Para esto debería [[coef global de transferencia de calor unidades]]
- podría preguntar en chegg 
- [[teoría-intercambiador-de-calor]]
- david tiene esto del flujo antes de la entrada al intercambiador de calor:
![[determinar-potencia-de-un-intercambiador-calor-tubo-carcasa-1702321448245.jpeg]]
- este valor está mal el del 3.71 x 10^5 ya que para pasar a MJ debes dividir por 1 millón = 1,000,000 y sería 3.71 x 10^4 MJ.
- P_002 es la entrada al intercambiador de calor
- la salida es P_003
- 
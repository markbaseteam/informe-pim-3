---
dg-publish: "true"
---

- Esta es la corriente de entrada en m3 o gal/h al flash tank:
![[estimar-dimensionamiento-flash-tank-1700878663662.jpeg]]
- se la he enviado al profesor parada para consultarle sobre el dimensionamiento de este equipo, ya que no está en capcosts y no lo encuentro en el sitio web que recomendó.

- ### FLASH VESSEL

- The flash vessel is located after the autoclave and prepares the slurry for further processing. The purpose of the flash vessel is to return the slurry to atmospheric conditions, minimizing solids carryover. This is done in stages if needed using one or several flash vessels. The steam generated in the flash vessel can be used by energy recovery systems. // Es lo mismo que hace nuestro equipo!! esto lo encontré en [Beginners guide to hydrometallurgical Autoclave processes - Metso](https://www.metso.com/insights/blog/mining-and-metals/beginners-guide-to-hydrometallurgical-autoclave-processes/)

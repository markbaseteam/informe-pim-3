---
dg-publish: "true"
---

- hay una página web que se llama equipcost 
- en donde hay varios reactores de separación sólido-líquido o de ing. química
- considerar el valor de impuestos por 35 % en Chile para traer ese equipo para acá. 
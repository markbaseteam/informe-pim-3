---
dg-publish: "true"
---

- por ejemplo para los espesadores está como el conventional thickener
- estimar el área de espesador y el diámetro del espesador
- calcular el área del espesador
- actualizar el valor real por el M&S
- todo representarlos en valor de USD
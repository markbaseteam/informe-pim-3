---
dg-publish: "true"
---

- [Tank agitator power calculation : step by step guide (myengineeringtools.com)](https://myengineeringtools.com/Piping/Power_Agitator_Calculation.html)
- estimación de precio de un agitador, por ejemplo para el estanque de acidificación tiene que ser un material de acero inoxidable 316 L
![[estimar-dimensionamiento-agitator-tank-1700792789438.jpeg]]
- alimentación:

- 200 m^3 en batch volume, de esta página:
- Una bomba hidráulica podría tener una relación con un tanque de agitación? [[consultas-proyecto-PIM]] NO, el profe me respondió que no tenían ninguna relación. 
- [Cálculo de la potencia de una bomba hidraulica - Gargil Suministros](https://gargil.es/calculo-de-la-potencia-de-una-bomba-hidraulica/)
![[estimar-dimensionamiento-TPOX-autoclaves-1700791981293.jpeg]]
- con respecto a las consultas que le hice al profesor parada el día viernes, me contestó de que hay efectivamente una forma para dimensionar y calcular el costo de un tanque de acidificación. Pero, hay que colocar de tipo "impeller" 
- entregar el valor del volumen, en esta misma página
- y el profesor aprobó de que tiene que ser de un material acero inoxidable 316L
##### 07_12
- determinar la potencia del agitador en HP o en kW [[determinar-potencia-de-un-agitador-porc-sólidos]]
	- y con esto se podría calcular el costo energético y el costo del equipo. 
- [[determinar-costo-de-tanque-de-acidificación]]
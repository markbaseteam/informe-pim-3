---
dg-publish: "true"
---

- para un agitador o motor
- qué potencia necesita el motor para agitar eso
- depende de las propiedades de la pulpa, viscosidad p de sólidos, densidad
- esto para calcular la energía eléctrica del equipo primero se debe determinar la potencia. 
- esta alternativa escogida ha sido ampliamente estudiada, consta de la oxidación a presión y temperatura alta en un reactor llamado autoclave


- las autoclaves están diseñadas para operar dentro de los 175 a 230°C lo que minimiza los costos de capital. 
- se hace innecesaria la inversión en sistemas sofisticados de tratamiento de gases para los metales asociados a los sulfuros
- permite la producción de ácido sulfúrico
- permite la recirculación de ácido al primer estanque del proceso
- aporta la energía necesaria para que opere el intercambiador de calor
- permite una reacción autógena en el autoclave, altamente exotérmica y sin cambio de fase para la pulpa a esas condiciones, con una alta tasa de conversión usando oxígeno
- más efectivo que la cianuración directa, sobre el 90 % de recuperación
- bajo consumo de NaCN para la cianuración
- desventaja: control de efluentes como corrientes de arsenopirita y de ácido
- es más costosa que la tostación, pero con mayor recuperación 90% v/s 80 %
·         Evaluación técnica y Económica para la producción de oro metal a partir de un concentrado de oro asociado con la pirita.

·         Análisis del mercado del oro y del ácido sulfúrico en Chile.

·         Brindar mayor conocimiento sobre las alternativas propuestas y presentarlas.

·         Dimensionar los equipos para la planta con la vía de tratamiento escogido en base al balance de masa realizado.

·         Obtener variables de evaluación de proyectos como la VAN y la TIR del proyecto, aparte de otros parámetros como IVAN, Payback.

·         Realizar un análisis de sensibilidad del proyecto de tal manera de obtener la relación entre el costo de tratamiento maquila y la VAN.
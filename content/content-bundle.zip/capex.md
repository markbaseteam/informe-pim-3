---
dg-publish: "true"
---

* motor tanque de potencia del motor
* mayor kW y al hacer funcionar te consume más 
* la potencia asociada al equipo para cuanto cuesta
* [[costo de operación]] asociado a la energía que gasta para saber cuanto consume
* para comprar la ampolleta necesitamos la potencia
* lo que es energía y potencia hay una diferencia
* [[potencia]]
* 95 o 90 lo que podría estar trabajando
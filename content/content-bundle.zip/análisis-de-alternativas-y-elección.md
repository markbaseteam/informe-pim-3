- simplemente tengo que enumerar todas las alternativas y hacer un resumen importante de cada una de ellas, establecer las relaciones detrás de cada proceso, etc
- nombrar parámetros comparativos como la recuperación, el coste de los equipos, costo de operación, etc

- script:
- Las principales alternativas propuestas nombradas en el segundo informe, fueron:
	- [[la tostación-pirita-refractaria]]
	- [[la oxidación biológica]]
	- mientras que la [[alternativa-elegida-tratamiento-medio-ácido]]
---
dg-home: "true"
dg-publish: "true"
---


- tiene 6 partes
- la parte más importante es la evaluación técnica, descripción del proceso o proyecto
- parte 7 es la evaluación del proyecto
- tener bien en consideración las diferencias que existen en la situación "con y sin proyecto"
### Informe final
1. Resumen ejecutivo
- En pocas líneas, se debe entregar una visión clara de la temática del proyecto y sus principales conclusiones
2. Introducción
- Desarrollar el marco o el escenario donde el proyecto se desarrolla y su importancia
3. Objetivos del proyecto
- Plantear claramente las metas buscadas, el proyecto debe quedar bien definido
4. Análisis del mercado
- Disponer de la información necesaria para asegurar la comercialización del producto, como la situación de la Oferta/Demanda, precios, etc
	- poner todo lo del informe anterior o bien esa parte resumida
	- agregar la parte de la comercialización, oferta/demanda del ácido sulfúrico, ya que también es un producto de nuestro proyecto.
5. Alternativas propuestas y su presentación
6. Evaluación técnica
- Para la o las alternativas seleccionadas, se debe evaluar técnicamente el proyecto considerando:
	- Descripción del proceso y/o proyecto
	- Antecedentes teóricos soportantes
	- Diagramas de flujos
	- Balances de masa y energía
	- Dimensionamiento de equipos
	- Layout de la planta
7. Evaluación económica
- Interesa principalmente determinar las inversiones del proyecto, sus costos operacionales, flujo de caja proyectado en el horizonte de evaluación. Para la evaluación del proyecto, se recomienda el cálculo de: TIR, VAN, IVAN, también incluir análisis de sensibilidad.
8. Conclusiones

_FECHA DE ENTREGA_
- 15 DE DICIEMBRE

[[defensa-pim]]
### Consultas
- La justificación del primer informe es la introducción para el último, eso se mantiene

### Clase de Evaluación económica 13 Nov
- [[pauta evaluación económica]]

- [[dimensionamiento de equipos]]


### Dimensionamiento de Equipos
- [[dimensionamiento-de-equipos-PIM]]

- mediante la app de digital garden podría crear otro sitio web y compartir todas las notas

### Presentación
- [[presentación-final-PIM]]